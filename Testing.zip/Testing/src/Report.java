public class Report {

    public double getAvgSaleQuant() {
        return avgSaleQuant;
    }

    public void setAvgSaleQuant(double avgSaleQuant) {
        this.avgSaleQuant = avgSaleQuant;
    }

    private double avgSaleQuant;

    public double getRevenue() {
        return revenue;
    }

    public void setRevenue(double revenue) {
        this.revenue = revenue;
    }

    private double revenue;

    public int getNumProducts() {
        return numProducts;
    }

    public void setNumProducts(int numProducts) {
        this.numProducts = numProducts;
    }

    private int numProducts;

    public double getAvgSale() {
        return avgSale;
    }

    public void setAvgSale(double avgSale) {
        this.avgSale = avgSale;
    }

    private double avgSale;

    public int getNumSales() {
        return numSales;
    }

    public void setNumSales(int numSales) {
        this.numSales = numSales;
    }

    private int numSales;


}
