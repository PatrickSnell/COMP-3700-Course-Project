import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PasswordController implements ActionListener {
    private PasswordView passwordView;
    private DataAdapter dataAdapter;

    public PasswordController(PasswordView passwordView, DataAdapter dataAdapter) {
        this.dataAdapter = dataAdapter;
        this.passwordView = passwordView;

        //passwordView.getBtnLoad().addActionListener(this);
        passwordView.getBtnSave().addActionListener(this);
    }


    public void actionPerformed(ActionEvent e) {
        //if (e.getSource() == productView.getBtnLoad())
        //    loadProduct();
        //else
        if (e.getSource() == passwordView.getBtnSave())
            savePassword();
    }

    private void savePassword() {
        int userID;
        try {
            userID = Integer.parseInt(passwordView.getTxtUserId().getText());
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid user ID!");
            return;
        }

        String newpassword = passwordView.getTxtNewPassword().getText().trim();
        if (newpassword.length() == 0) {
            JOptionPane.showMessageDialog(null, "Invalid password!");
            return;
        }

        Password password = new Password();
        password.setUserId(userID);
        password.setNewPassword(newpassword);


        // Store the password to the database

        dataAdapter.savePassword(password);
    }

    private void loadOldPassword() {
        String p1 = null;
        try {
            p1 = passwordView.getTxtOldPassword().getText();
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid password! Please provide a valid password!");
            return;
        }

        Password pass = dataAdapter.loadPassword(p1);

        if (pass == null) {
            JOptionPane.showMessageDialog(null, "This password does not exist in the database!");
            return;
        }

        passwordView.getTxtOldPassword().setText(String.valueOf(pass.getOldPassword()));
    }

}