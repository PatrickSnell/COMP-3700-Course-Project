import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PasswordController implements ActionListener {
    private PasswordView passwordView;
    private DataAdapter dataAdapter;

    public PasswordController(PasswordView passwordView, DataAdapter dataAdapter) {
        this.dataAdapter = dataAdapter;
        this.passwordView = passwordView;

        //passwordView.getBtnLoad().addActionListener(this);
        passwordView.getBtnSave().addActionListener(this);
    }


    public void actionPerformed(ActionEvent e) {
        //if (e.getSource() == productView.getBtnLoad())
        //    loadProduct();
        //else
        if (e.getSource() == passwordView.getBtnSave())
            savePassword();
    }

    private void savePassword() {
        int userID;
        try {
            userID = Integer.parseInt(passwordView.getTxtUserId().getText());
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid user ID!");
            return;
        }

        String newpassword = passwordView.getTxtNewPassword().getText().trim();
        if (newpassword.length() == 0) {
            JOptionPane.showMessageDialog(null, "Invalid password!");
            return;
        }

        Password password = new Password();
        password.setUserId(userID);
        password.setNewPassword(newpassword);


        // Store the password to the database

        dataAdapter.savePassword(password);
    }
/*
    private void loadProduct() {
        int productID = 0;
        try {
            productID = Integer.parseInt(productView.getTxtProductID().getText());
        }
        catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid product ID! Please provide a valid product ID!");
            return;
        }

        Product product = dataAdapter.loadProduct(productID);

        if (product == null) {
            JOptionPane.showMessageDialog(null, "This product ID does not exist in the database!");
            return;
        }

        productView.getTxtProductName().setText(product.getName());
        productView.getTxtProductPrice().setText(String.valueOf(product.getPrice()));
        productView.getTxtProductQuantity().setText(String.valueOf(product.getQuantity()));
        productView.getTxtProvider().setText(String.valueOf(product.getproviderName()));
        productView.getTxtContact().setText(String.valueOf(product.getproviderContact()));
    }
*/
}