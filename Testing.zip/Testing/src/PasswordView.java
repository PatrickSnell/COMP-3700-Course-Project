import javax.swing.*;

public class PasswordView extends JFrame{
    private JTextField txtPassword  = new JTextField(10);

    private JButton btnSave = new JButton("Save Password");

    public PasswordView() {
        this.setTitle("Change Password");
        this.setLayout(new BoxLayout(this.getContentPane(), BoxLayout.PAGE_AXIS));
        this.setSize(500, 400);

        JPanel panelButton = new JPanel();
        panelButton.add(btnSave);
        this.getContentPane().add(panelButton);

        JPanel panelProductID = new JPanel();
        panelProductID.add(new JLabel("New Password: "));
        panelProductID.add(txtPassword);
        txtPassword.setHorizontalAlignment(JTextField.RIGHT);
        this.getContentPane().add(panelProductID);


    }

    public JButton getBtnSave() {
        return btnSave;
    }

    public JTextField getTxtPassword() {
        return txtPassword;
    }

}