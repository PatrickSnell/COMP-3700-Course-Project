public class Password {
    private int userid;
    private String oldpassword;
    private String newpassword;

    public int getUserId() {
        return userid;
    }

    public void setUserId(int userid) {
        this.userid = userid;
    }

    public String getOldPassword() {
        return oldpassword;
    }

    public void setOldPassword(String oldpassword) {
        this.oldpassword = oldpassword;
    }

    public String getNewPassword() {
        return newpassword;
    }

    public void setNewPassword(String newpassword) {
        this.newpassword = newpassword;
    }

}
