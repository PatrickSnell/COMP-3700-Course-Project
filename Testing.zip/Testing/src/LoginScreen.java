import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginScreen extends JFrame {

    private JTextField txtUserId  = new JTextField(20);
    private JTextField txtPassword  = new JTextField(20);


    private JButton btnLogin = new JButton("Login");
    private JButton btnChangePassword   = new JButton("Change Password");
    private JButton btnChangePic  = new JButton("Change Picture");

    public LoginScreen () {
        this.setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(500, 300);

        btnChangePassword.setPreferredSize(new Dimension(120, 50));
        btnLogin.setPreferredSize(new Dimension(120, 50));
        btnChangePic.setPreferredSize(new Dimension(120, 50));


        JLabel title = new JLabel("Login");
        title.setFont(new Font("Times New Roman", Font.BOLD, 24));
        JPanel panelTitle = new JPanel();
        panelTitle.add(title);
        this.getContentPane().add(panelTitle);


        JPanel panelProductID = new JPanel();
        panelProductID.add(new JLabel("User ID: "));
        panelProductID.add(txtUserId);
        this.getContentPane().add(panelProductID);

        JPanel panelProductName = new JPanel();
        panelProductName.add(new JLabel("Password: "));
        panelProductName.add(txtPassword);
        this.getContentPane().add(panelProductName);


        JPanel panelButton = new JPanel();
        panelButton.add(btnLogin);
        panelButton.add(btnChangePassword);
        panelButton.add(btnChangePic);

        this.getContentPane().add(panelButton);

        btnLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {


                // want to check if user id and password are valid, if so go to either Product or Checkout screen


                Application.getInstance().getCheckoutScreen().setVisible(true);            }
        });


        btnChangePassword.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Application.getInstance().getProductView().setVisible(true);
            }
        });

        btnChangePic.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Application.getInstance().getProductView().setVisible(true);
            }
        });
    }


}
