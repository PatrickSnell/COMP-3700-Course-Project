public class User {
    private int userID;
    private String userName;
    private String password;
    private boolean isManager;
    private String displayName;


    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public void setManager(boolean manager) {
        isManager = manager;
    }

    public String getDisplayName() {
        return displayName;
    }

    public boolean isManager() {
        return isManager;
    }
    //finish getters and setters
}
