import java.sql.*;

public class Application {

    private static Application instance;   // Singleton pattern

    public static Application getInstance() {
        if (instance == null) {
            instance = new Application();
        }
        return instance;
    }
    // Main components of this application

    private Connection connection;

    public Connection getConnection() {
        return connection;
    }

    private DataAdapter dataAdapter;

    private AddProduct productView;

    private MainScreen mainScreen;

    public MainScreen getMainScreen() {
        return mainScreen;
    }

    public AddProduct getProductView() {
        return productView;
    }

    private ProductController productController;

    public ProductController getProductController() {
        return productController;
    }

    public DataAdapter getDataAdapter() {
        return dataAdapter;
    }

    private Application() {
        // create SQLite database connection here!
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/Store_Management_System","root","Bravesfan42");
        }
        catch (ClassNotFoundException ex) {
            System.out.println("Database could not be loaded");
            System.out.println(ex.getMessage());
            ex.printStackTrace();
//            System.exit(1);
        }

        catch (SQLException ex) {
            System.out.println("Database could not be loaded");
            System.out.println(ex.getSQLState() + ex.getMessage());
            System.exit(2);
        }

        // Create data adapter here!
        dataAdapter = new DataAdapter(connection);

        // Create the Product View and Controller here!

        productView = new AddProduct();

        productController = new ProductController(productView, dataAdapter);

        mainScreen = new MainScreen();

    }


    public static void main(String[] args) {
        Application.getInstance().getMainScreen().setVisible(true);
    }
}
