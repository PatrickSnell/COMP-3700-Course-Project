import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainScreen extends JFrame {

    private JButton Checkout = new JButton("Checkout");
    private JButton NewProduct   = new JButton("Add New Product");
    private JButton UpdateProduct   = new JButton("Update Existing Product");

    public MainScreen() {
        this.setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(350, 350);

        Checkout.setPreferredSize(new Dimension(150, 50));
        NewProduct.setPreferredSize(new Dimension(150, 50));
        UpdateProduct.setPreferredSize(new Dimension(180, 50));

        JLabel title = new JLabel("Store Management System");
        title.setFont(new Font("Times New Roman", Font.BOLD, 24));
        JPanel panelTitle = new JPanel();
        panelTitle.add(title);
        this.getContentPane().add(panelTitle);

        JPanel panelButton = new JPanel();
        panelButton.add(Checkout);
        //JPanel panelButton2 = new JPanel();
        panelButton.add(NewProduct);
        //JPanel panelButton3 = new JPanel();
        panelButton.add(UpdateProduct);

        this.getContentPane().add(panelButton);

        Checkout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "This function is to be implemented!");
            }
        });


        NewProduct.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Application.getInstance().getProductView().setVisible(true);
            }
        });

        UpdateProduct.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Application.getInstance().getProductView().setVisible(true);
            }
        });
    }
}
